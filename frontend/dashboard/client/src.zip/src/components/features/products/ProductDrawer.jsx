import { useEffect, useMemo, useRef, useState } from "react";
import PriceHistory from "../charts/PriceHistory";
import PricingPanel from "./PricingPanel";
import ProductThumb from "./ProductThumb";
import { Button } from "../../ui/Button";
import { api } from "../../../lib/api";
import { formatMoney } from "../../../lib/utils";

function normMoney(v) {
    const n = Number(v);
    if (!Number.isFinite(n) || n <= 0) return null;
    return n;
}

export default function ProductDrawer({ open, onClose, product, fetchJson, onProductUpdate }) {
    const drawerRef = useRef(null);

    // DB-view state
    const [dbView, setDbView] = useState(null);
    const [dbLoading, setDbLoading] = useState(false);
    const [dbErr, setDbErr] = useState("");

    const isDb = !!product?.__dbCompanyId;

    // Keep a stable "p" that is null when drawer is closed
    const p = useMemo(() => (open && product ? product : null), [open, product]);

    useEffect(() => {
        function onKey(e) {
            if (e.key === "Escape") onClose?.();
        }
        function onDocMouseDown(e) {
            if (!drawerRef.current?.contains(e.target)) onClose?.();
        }

        if (open) {
            window.addEventListener("keydown", onKey);
            document.addEventListener("mousedown", onDocMouseDown);
            document.body.classList.add("drawer-open");
        } else {
            document.body.classList.remove("drawer-open");
        }

        return () => {
            window.removeEventListener("keydown", onKey);
            document.removeEventListener("mousedown", onDocMouseDown);
            document.body.classList.remove("drawer-open");
        };
    }, [open, onClose]);

    // Fetch DB view when needed
    useEffect(() => {
        if (!open || !product || !isDb) {
            setDbView(null);
            setDbErr("");
            setDbLoading(false);
            return;
        }

        let alive = true;
        (async () => {
            setDbLoading(true);
            setDbErr("");
            try {
                const view = await api.fetchDbProductViewByCompany(product.__dbCompanyId);
                if (!alive) return;
                setDbView(view);
            } catch (e) {
                if (!alive) return;
                setDbErr(String(e?.message || e));
                setDbView(null);
            } finally {
                if (alive) setDbLoading(false);
            }
        })();

        return () => {
            alive = false;
        };
    }, [open, product, isDb]);

    // Prefer DB view data if present (derived values; NOT hooks)
    const company = dbView?.company || dbView?.companyListing || dbView?.listing || null;
    const market = dbView?.market || dbView?.snapshot || dbView?.marketSnapshot || null;
    const offers = dbView?.offers || dbView?.marketOffers || null;
    const rec = dbView?.recommended || dbView?.pricing || null;

    // IMPORTANT: Hooks must always run in the same order.
    // So we compute merged via useMemo first, then conditionally return null afterwards.
    const merged = useMemo(() => {
        if (!p) return null;

        if (!isDb) return p;

        // Merge company listing with whatever pricing/snapshot returned
        const base = {
            ...p,

            // normalize expected fields
            id: company?.id ?? p.id,
            name: company?.name ?? p.name,
            brand: company?.brand ?? p.brand,
            category: company?.category ?? p.category,
            ean: company?.ean ?? p.ean,
            mpn: company?.mpn ?? p.mpn,

            ourPrice: company?.ourPrice ?? company?.our_price ?? p.ourPrice ?? p.price,
            costPrice: company?.costPrice ?? company?.cost_price ?? p.costPrice,

            priceMode: company?.priceMode ?? company?.price_mode ?? p.priceMode ?? "AUTO",
            manualPrice: company?.manualPrice ?? company?.manual_price ?? p.manualPrice ?? null,

            recommendedPrice:
                rec?.recommendedPrice ??
                rec?.recommended ??
                market?.benchmarkPrice ??
                market?.benchmark_price ??
                p.recommendedPrice ??
                null,

            effectivePrice: rec?.effectivePrice ?? rec?.effective ?? p.effectivePrice ?? null,
        };

        return base;
    }, [isDb, p, company, market, rec]);

    // Keep returns AFTER hooks
    if (!open || !p || !merged) return null;

    const eanKey = merged?.ean != null ? String(merged.ean) : "";

    const currentPrice = normMoney(merged.ourPrice ?? merged.price);
    const recommendedPrice = normMoney(merged.recommendedPrice ?? market?.benchmarkPrice ?? market?.benchmark_price);
    const minPrice = normMoney(market?.priceMin ?? market?.price_min);
    const maxPrice = normMoney(market?.priceMax ?? market?.price_max);
    const offersCount = market?.offersCount ?? market?.offers_count;

    return (
        <>
            <div className="drawerOverlay" onClick={onClose} />
            <aside ref={drawerRef} className="drawer">
                <div className="drawerHeader">
                    <div style={{ minWidth: 0 }}>
                        <div className="drawerTitle" title={merged.name}>
                            {merged.name}
                        </div>
                        <div className="drawerSub">
                            {merged.brand} · {merged.category}
                        </div>
                    </div>
                    <Button onClick={onClose} variant="secondary" size="sm">
                        Close
                    </Button>
                </div>

                <div className="drawerContent">
                    {merged.imageUrl && (
                        <div className="drawerImgBox">
                            <img src={merged.imageUrl} alt={merged.name} loading="lazy" className="drawerImg" />
                        </div>
                    )}

                    <div className="drawerCard">
                        <div className="drawerCardTop">
                            <div>
                                <div className="drawerLabel">EAN</div>
                                <div className="drawerEan">{merged.ean || "—"}</div>
                            </div>
                            <div style={{ textAlign: "right" }}>
                                <div className="drawerLabel">Source</div>
                                <div className="drawerEan">{merged.store || (isDb ? "DB" : "—")}</div>
                            </div>
                        </div>

                        <div className="drawerMeta">
                            ID: {merged.id ?? "—"} {isDb ? <>· CompanyId: {product.__dbCompanyId}</> : null}
                        </div>

                        {merged.url && (
                            <a href={merged.url} target="_blank" rel="noreferrer" className="drawerLink">
                                Open productURL →
                            </a>
                        )}
                    </div>

                    {/* DB extra panel */}
                    {isDb ? (
                        <div className="drawerCard" style={{ marginTop: 12 }}>
                            <div className="drawerCardTop">
                                <div>
                                    <div className="drawerLabel">DB View</div>
                                    <div className="drawerEan">{dbLoading ? "Loading…" : dbErr ? "Error" : "OK"}</div>
                                </div>
                                <div style={{ textAlign: "right" }}>
                                    <div className="drawerLabel">Offers</div>
                                    <div className="drawerEan">{offersCount ?? (Array.isArray(offers) ? offers.length : "—")}</div>
                                </div>
                            </div>

                            {dbErr ? (
                                <div style={{ marginTop: 8, opacity: 0.9 }}>
                                    <strong style={{ color: "var(--danger)" }}>DB error:</strong> {dbErr}
                                </div>
                            ) : null}

                            {!dbLoading && !dbErr ? (
                                <div style={{ marginTop: 10, display: "grid", gap: 6 }}>
                                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                                        <span style={{ opacity: 0.75 }}>Current</span>
                                        <span>{currentPrice ? formatMoney(currentPrice) : "—"}</span>
                                    </div>
                                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                                        <span style={{ opacity: 0.75 }}>Recommended</span>
                                        <span>{recommendedPrice ? formatMoney(recommendedPrice) : "—"}</span>
                                    </div>
                                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                                        <span style={{ opacity: 0.75 }}>Market min</span>
                                        <span>{minPrice ? formatMoney(minPrice) : "—"}</span>
                                    </div>
                                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                                        <span style={{ opacity: 0.75 }}>Market max</span>
                                        <span>{maxPrice ? formatMoney(maxPrice) : "—"}</span>
                                    </div>
                                </div>
                            ) : null}
                        </div>
                    ) : null}

                    {/* PricingPanel */}
                    <PricingPanel
                        productKey={eanKey}
                        product={merged}
                        onProductPatched={(patch) => {
                            if (!patch) return;
                            onProductUpdate?.({ ...merged, ...patch });
                        }}
                    />

                    {/* PriceHistory */}
                    <PriceHistory fetchJson={fetchJson} ean={eanKey} title="Pricehistory" />
                </div>
            </aside>
        </>
    );
}