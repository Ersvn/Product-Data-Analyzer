import { useState, useCallback, useEffect, useRef } from "react";
import { useSearchParams } from "react-router-dom";
import { api } from "../lib/api";
import { useDebounce } from "../hooks/useDebounce";
import { Button } from "../components/ui/Button";
import { Input } from "../components/ui/Input";
import { Skeleton } from "../components/ui/Skeleton";
import { ErrorState } from "../components/ui/ErrorState";
import { Badge } from "../components/ui/Badge";
import ProductDrawer from "../components/features/products/ProductDrawer";
import ProductThumb from "../components/features/products/ProductThumb";
import PriceModeBadge from "../components/features/products/PriceModeBadge";
import { formatMoney, cn, downloadCSV } from "../lib/utils";

const PAGE_SIZE = 100;

const SearchIcon = () => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <circle cx="11" cy="11" r="8" />
        <path d="m21 21-4.35-4.35" />
    </svg>
);

function rowKeyFor(source, p) {
    if (!p) return "unknown";

    if (source === "db") {
        // DB inventory rows have __dbCompanyId (same as id)
        return `db:${p.__dbCompanyId ?? p.id}`;
    }

    if (source === "company") {
        // JSON inventory – avoid collisions with market by prefix + stable identifier
        return `company:${p.companySku ?? p.company_sku ?? p.sku ?? p.ean ?? p.id}`;
    }

    // market (JSON)
    return `market:${p.ean ?? p.id}`;
}

export default function ProductsPage() {
    const [searchParams, setSearchParams] = useSearchParams();

    const [source, setSource] = useState(searchParams.get("source") || "market"); // market | company | db
    const [q, setQ] = useState(searchParams.get("q") || "");
    const debouncedQ = useDebounce(q, 300);

    const [rows, setRows] = useState([]);
    const [meta, setMeta] = useState({ total: 0, page: 1, totalPages: 1 });

    const [page, setPage] = useState(1); // JSON paging only
    const [loading, setLoading] = useState(false);
    const [err, setErr] = useState("");
    const [selected, setSelected] = useState(null);

    // IMPORTANT: overrides keyed by __rowKey (namespaced), not raw id
    const [overrides, setOverrides] = useState(new Map());

    const [createOpen, setCreateOpen] = useState(false);
    const [bulkLoading, setBulkLoading] = useState(false);
    const [bulkMsg, setBulkMsg] = useState("");

    const listRef = useRef(null);

    // DB keyset paging refs (IMPORTANT: prevents blink loop)
    const dbAfterIdRef = useRef(0);
    const dbHasMoreRef = useRef(true);

    // prevent overlapping requests
    const inFlightRef = useRef(false);

    useEffect(() => {
        const params = new URLSearchParams();
        if (source !== "market") params.set("source", source);
        if (q) params.set("q", q);
        setSearchParams(params, { replace: true });
    }, [source, q, setSearchParams]);

    const normalizeDbListing = (r) => {
        const out = {
            id: r.id,
            __dbCompanyId: r.id,
            name: r.name ?? "",
            brand: r.brand ?? "",
            category: r.category ?? "",
            ean: r.ean ?? null,
            mpn: r.mpn ?? null,
            ourPrice: r.ourPrice ?? r.our_price ?? null,
            costPrice: r.costPrice ?? r.cost_price ?? null,
            priceMode: r.priceMode ?? r.price_mode ?? "AUTO",
            manualPrice: r.manualPrice ?? r.manual_price ?? null,
            imageUrl: r.imageUrl ?? r.image_url ?? null,
            url: r.url ?? null,
            store: r.store ?? null,
        };

        return {
            ...out,
            __source: "db",
            __rowKey: rowKeyFor("db", out),
        };
    };

    const attachKeys = (src, items) =>
        items.map((p) => ({
            ...p,
            __source: src,
            __rowKey: rowKeyFor(src, p),
        }));

    const fetchFirstPage = useCallback(async () => {
        if (inFlightRef.current) return;
        inFlightRef.current = true;

        setLoading(true);
        setErr("");

        try {
            if (source === "db") {
                dbAfterIdRef.current = 0;
                dbHasMoreRef.current = true;

                const res = await api.fetchDbCompanyListings({
                    q: debouncedQ,
                    afterId: 0,
                    limit: PAGE_SIZE,
                });

                const items = Array.isArray(res) ? res : res?.items ?? [];
                const normalized = items.map(normalizeDbListing);

                setRows(normalized);

                const last = normalized[normalized.length - 1];
                dbAfterIdRef.current = last?.id ?? 0;

                dbHasMoreRef.current = normalized.length === PAGE_SIZE;

                setMeta({
                    total: normalized.length,
                    page: 1,
                    totalPages: dbHasMoreRef.current ? 2 : 1,
                });

                return;
            }

            // JSON mode
            const endpoint = source === "company" ? "fetchCompanyProducts" : "fetchProducts";
            const res = await api[endpoint]({ q: debouncedQ, page: 1, limit: PAGE_SIZE });

            const newData = Array.isArray(res?.data) ? res.data : Array.isArray(res) ? res : [];
            const withKeys = attachKeys(source, newData);

            const newMeta =
                res?.meta || {
                    total: res?.total || 0,
                    page: 1,
                    totalPages: Math.ceil((res?.total || 0) / PAGE_SIZE) || 1,
                };

            setRows(withKeys);
            setMeta(newMeta);
            setPage(1);
        } catch (e) {
            setErr(String(e?.message || e));
        } finally {
            setLoading(false);
            inFlightRef.current = false;
        }
    }, [source, debouncedQ]);

    const fetchMore = useCallback(async () => {
        if (loading) return;
        if (inFlightRef.current) return;

        if (source === "db" && !dbHasMoreRef.current) return;
        if (source !== "db" && meta.page >= meta.totalPages) return;

        inFlightRef.current = true;
        setLoading(true);
        setErr("");

        try {
            if (source === "db") {
                const res = await api.fetchDbCompanyListings({
                    q: debouncedQ,
                    afterId: dbAfterIdRef.current,
                    limit: PAGE_SIZE,
                });

                const items = Array.isArray(res) ? res : res?.items ?? [];
                const normalized = items.map(normalizeDbListing);

                setRows((prev) => [...prev, ...normalized]);

                const last = normalized[normalized.length - 1];
                if (last?.id != null) dbAfterIdRef.current = last.id;

                dbHasMoreRef.current = normalized.length === PAGE_SIZE;

                setMeta((prev) => ({
                    total: prev.total + normalized.length,
                    page: prev.page + 1,
                    totalPages: dbHasMoreRef.current ? prev.page + 2 : prev.page + 1,
                }));

                return;
            }

            // JSON mode
            const nextPage = page + 1;
            const endpoint = source === "company" ? "fetchCompanyProducts" : "fetchProducts";
            const res = await api[endpoint]({ q: debouncedQ, page: nextPage, limit: PAGE_SIZE });

            const newData = Array.isArray(res?.data) ? res.data : Array.isArray(res) ? res : [];
            const withKeys = attachKeys(source, newData);

            setRows((prev) => [...prev, ...withKeys]);

            const newMeta = res?.meta || meta;
            setMeta(newMeta);
            setPage(nextPage);
        } catch (e) {
            setErr(String(e?.message || e));
        } finally {
            setLoading(false);
            inFlightRef.current = false;
        }
    }, [source, debouncedQ, loading, meta, page]);

    useEffect(() => {
        // reset state on source/search changes
        setRows([]);
        setMeta({ total: 0, page: 1, totalPages: 1 });
        setPage(1);
        dbAfterIdRef.current = 0;
        dbHasMoreRef.current = true;
        setOverrides(new Map());
        setSelected(null);
        fetchFirstPage();
    }, [source, debouncedQ, fetchFirstPage]);

    useEffect(() => {
        const el = listRef.current;
        if (!el) return;

        const onScroll = () => {
            const bottom = el.scrollHeight - el.scrollTop - el.clientHeight < 200;
            const canScroll = el.scrollHeight > el.clientHeight + 10;
            if (bottom && canScroll) fetchMore();
        };

        el.addEventListener("scroll", onScroll);
        return () => el.removeEventListener("scroll", onScroll);
    }, [fetchMore]);

    const handleExport = () => {
        const data = rows.map((r) => ({
            Namn: r.name,
            EAN: r.ean,
            Brand: r.brand,
            Kategori: r.category,
            Pris: r.price || r.ourPrice,
            Butik: r.store,
            Läge: r.priceMode || "AUTO",
        }));
        downloadCSV(data, `produkter-${source}-${new Date().toISOString().split("T")[0]}.csv`);
    };

    const applyOverride = (updated) => {
        if (!updated) return;

        // ALWAYS use namespaced key (prevents market<->company contamination)
        const key =
            updated.__rowKey ||
            selected?.__rowKey ||
            rowKeyFor(source, updated);

        if (!key) return;

        setOverrides((prev) => {
            const next = new Map(prev);
            next.set(String(key), updated);
            return next;
        });

        setSelected((prev) => (prev ? { ...prev, ...updated, __rowKey: key } : null));

        setRows((prev) =>
            prev.map((r) => (String(r.__rowKey) === String(key) ? { ...r, ...updated, __rowKey: key } : r))
        );
    };

    const getEffectivePrice = (p) => {
        const key = p.__rowKey || rowKeyFor(source, p);
        const override = overrides.get(String(key));
        const product = override ? { ...p, ...override } : p;

        const serverEff = Number(product.effectivePrice);
        if (Number.isFinite(serverEff) && serverEff > 0) return serverEff;

        if (product.priceMode === "MANUAL" && product.manualPrice != null) return product.manualPrice;

        return product.recommendedPrice || product.ourPrice || product.price;
    };

    const handleBulkRecompute = useCallback(async () => {
        setBulkMsg("");
        setErr("");
        setBulkLoading(true);

        try {
            const res = await api.recomputeAllPricing({ persist: true });
            setBulkMsg(
                `Klart: ${res?.recomputed ?? 0} omräknade, ${res?.skipped ?? 0} hoppade över, ${res?.errors ?? 0} fel (${res?.tookMs ?? 0} ms)`
            );

            setOverrides(new Map());
            fetchFirstPage();
        } catch (e) {
            setErr(String(e?.message || e));
        } finally {
            setBulkLoading(false);
        }
    }, [fetchFirstPage]);

    return (
        <section className="apage">
            <header className="apage__header">
                <div>
                    <div className="apage__kicker">Catalog</div>
                    <h1 className="apage__title">Products</h1>
                    <p className="apage__sub">Search, analyze and adjust prices</p>
                </div>

                <div className="apage__actions">
                    <Button variant="ghost" onClick={handleExport} disabled={!rows.length}>
                        Exportera CSV
                    </Button>

                    {source === "company" && (
                        <Button variant="secondary" onClick={handleBulkRecompute} disabled={bulkLoading || loading}>
                            {bulkLoading ? "Updating…" : "Update all prices"}
                        </Button>
                    )}

                    <Button onClick={() => setCreateOpen(true)}>New product</Button>
                </div>
            </header>

            <div className="apage__toolbar">
                <div className="segmented">
                    <button className={cn("segBtn", source === "market" && "segBtnActive")} onClick={() => setSource("market")}>
                        Market
                    </button>
                    <button className={cn("segBtn", source === "company" && "segBtnActive")} onClick={() => setSource("company")}>
                        Our inventory (JSON)
                    </button>
                    <button className={cn("segBtn", source === "db" && "segBtnActive")} onClick={() => setSource("db")}>
                        DB (Postgres)
                    </button>
                </div>

                <div className="apage__tools">
                    <Badge>
                        {source === "db"
                            ? `Loaded: ${rows.length.toLocaleString("sv-SE")}${dbHasMoreRef.current ? "+" : ""}`
                            : `Items: ${rows.length.toLocaleString("sv-SE")} / ${meta.total.toLocaleString("sv-SE")}`}
                    </Badge>

                    <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search products..." icon={<SearchIcon />} />
                </div>
            </div>

            {err && <ErrorState error={{ message: err }} retry={fetchFirstPage} />}

            <div ref={listRef} className={cn("virtualWrap", selected && "virtualWrap--with-drawer")}>
                {rows.map((p) => {
                    const price = getEffectivePrice(p);
                    return (
                        <div key={p.__rowKey || p.id || p.ean} className="virtualRow" onClick={() => setSelected(p)}>
                            <div className="virtualLeft">
                                <ProductThumb src={p.imageUrl} alt={p.name} />
                                <div className="virtualTexts">
                                    <div className="virtualTitle">{p.name}</div>
                                    <div className="virtualMeta">
                                        {p.brand} · {p.category} · {p.ean}
                                    </div>
                                </div>
                            </div>

                            <div className="virtualRight">
                                {(source === "company" || source === "db") && (
                                    <PriceModeBadge priceMode={p.priceMode} manualPrice={p.manualPrice} />
                                )}
                                <span className="virtualPrice">{formatMoney(price)}</span>
                            </div>
                        </div>
                    );
                })}

                {loading && (
                    <div style={{ padding: 20 }}>
                        <Skeleton height={60} />
                        <Skeleton height={60} style={{ marginTop: 8 }} />
                        <Skeleton height={60} style={{ marginTop: 8 }} />
                    </div>
                )}

                {!loading && source === "db" && !dbHasMoreRef.current && rows.length > 0 && <div className="listEnd">Inga fler produkter</div>}
                {!loading && source !== "db" && meta.page >= meta.totalPages && rows.length > 0 && <div className="listEnd">Inga fler produkter</div>}
            </div>

            <ProductDrawer
                open={!!selected}
                onClose={() => setSelected(null)}
                product={selected}
                fetchJson={api.request.bind(api)}
                onProductUpdate={applyOverride}
            />

            {createOpen ? (
                <div style={{ padding: 12, marginTop: 12, borderRadius: 12 }} className="panel">
                    <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
                        <strong>New Product (TODO)</strong>
                        <Button variant="ghost" onClick={() => setCreateOpen(false)}>
                            Close
                        </Button>
                    </div>
                </div>
            ) : null}
        </section>
    );
}